% Progrmming assignment for AP3132-Advanced Digital Image Processing course
% Instructor: B. Rieger, F. Vos 
% Tutor: H. Heydarian
% Term: Q3-2021
%
% Labwork #2
%
clear all, close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem #1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Part a: dilation and erosion

% read the original input image
I = readim(['images' filesep 'gold.tif']);
h=dipshow(I);
h.Name='original image';
h.NumberTitle='off';

	% add proper noise to make the image the same as the one depicted in the 
% manual (top-right in Figure 1)
% TODO3
J = noise(I,'saltpepper',0,0.1);
h = dipshow(J);
h.Name='noisy image';
h.NumberTitle='off';

% apply dilation to the noisy image
In = J;
I_max = max_f(In, 3);
h=dipshow(I_max);
h.Name='dilated image';
h.NumberTitle='off';

% apply erossion to the noisy image
I_min = min_f(In, 3);
h=dipshow((I_min));
h.Name='eroded image';
h.NumberTitle='off';

pause
%%
% Part b: closing and opening

% apply closing to the given image
% TODO4a

I_close =[]
h=dipshow(I_close);
h.Name='closing';
h.NumberTitle='off';

% apply openning to the given image
% TODO4b
I_open =[]
h=dipshow(I_open);
h.Name='opening';
h.NumberTitle='off';


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem #2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Part a: smoothing

% read the original input image
I = readim(['images' filesep 'trui.tif']);
h=dipshow(I);
h.Name='original image';
h.NumberTitle='off';

% TODO5
% add proper noise to make the image as depicted in the lecture notes
J = noise(I,'gaussian',1);
h=dipshow(J);
h.Name='noisy image';
h.NumberTitle='off';

In = J;
I_max = max_f(In, 3);
I_min = min_f(In, 3);

Iout1=[];
h=dipshow(Iout1);
h.Name='smoothed image (method1)';
h.NumberTitle='off';

Iout2=[];
h=dipshow(Iout2);
h.Name='smoothed image (method2)';
h.NumberTitle='off';

pause
%%
% Part b: image gradient

% read the original input image
I = readim(['images' filesep 'truinoise.tif']);
h=dipshow(I);
h.Name='original image';
h.NumberTitle='off';

% TODO6

% structuring element size
k = 5;

% TODO6a
% dilation
% erosion
% openning
% closing

% image gradient method 1 TODO6b
dyr =[]; 
h=dipshow(dyr);
h.Name='gradient  dyr';
h.NumberTitle='off';

% image gradient method 2 TODO6c
ter = [];
h=dipshow(ter);
h.Name='gradient  ter';
h.NumberTitle='off';

% image gradient method 3 TODO6d
rar = [];
h=dipshow(rar);
h.Name='gradient image rar';
h.NumberTitle='off';

% compare with gradmag() from diplib

%%
% Part c: Background removal

% read the original input image
I = readim(['images' filesep 'retinaangio.tif']);
h=dipshow(I);
h.Name='original image';
h.NumberTitle='off';

% TODO7
bg=[];

h=dipshow((bg));
h.Name='background';
h.NumberTitle='off';

h=dipshow((nobg));
h.Name='background removed';
h.NumberTitle='off';
